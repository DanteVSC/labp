from flask import Flask, render_template, request, abort, jsonify,redirect,url_for
import math
from  model import Produto
app = Flask(__name__)

elemento = Produto()
#lista de produtos
@app.route('/produtos')
def listar_produtos():
    return render_template('produtos.html', produtos=elemento.get_produtos())

@app.route('/admin')
def abrir_admin():
     return render_template('admin.html', produtos=elemento.get_produtos())

@app.route('/adicionar', methods=['POST','GET'])
def adicionar():
    nome = request.form.get('nome')
    preco = request.form.get('preco')
    elemento.add(nome,preco)
    return redirect(url_for('abrir_admin'))
    
@app.route('/deletar', methods=['POST','GET'])
def delete():
    id = request.form.get('id')    
    elemento.deletar(id)
    return redirect(url_for('abrir_admin'))

@app.route('/produtos-paginados')
def listar_produtos_paginados():
    page = request.arg.get('page', 1, type=int)
    per_page = 5

    #logica da paginacao    
    start = (page-1)*per_page
    end = start + per_page
    total_pages = math.ceil(len(PRODUTOS)/per_page)

    #pega itens apenas da pagina atual
    produtos_da_pagina = PRODUTOS[start:end]

    return render_template('produtos_paginados.html', produtos=produtos_da_pagina, page=page,total_pages=total_pages)

@app.route('/produto/<int:produto_id>')
def detalhe_produto(produto_id):
    produto_encontrado = None

    for produto in PRODUTOS:
        if produto["id"] == produto_id:
             produto_encontrado = produto
             break
    if produto_encontrado is None:
        abort(404) 
    return render_template('detalhe_produto.html',produto=produto_encontrado)

@app.route('/api/buscar-produto',methods=['POST'])
def buscar_produto():
    dados = request.get_json()
    nome_produto = dados.get('nome').lower()

    resultado = [p for p in PRODUTOS if nome_produto in p['nome'].lower()]

    return jsonify({'produtos_encontrados':resultado})

if __name__ == '__main__':
        app.run(debug=True)