from flask import Flask


class Produto:

    PRODUTOS = [
    {'id': 1, 'nome': 'Notebook Gamer', 'preco': 5200.00},
    {'id': 2, 'nome': 'Mouse sem fio', 'preco': 150.00},
    {'id': 3, 'nome': 'Teclado Mecanico RGB', 'preco': 350.00},
    {'id': 4, 'nome': 'Smartphone intermediário', 'preco': 1800.00},
    {'id': 5, 'nome': 'Smart TV 50 polegadas', 'preco': 3200.00},
    {'id': 6, 'nome': 'Fone de ouvido Bluetooth', 'preco': 250.00},
    {'id': 7, 'nome': 'Ventilador de coluna', 'preco': 260.00},
    {'id': 8, 'nome': 'Aspirador de pó e água', 'preco': 290.00},
    {'id': 9, 'nome': 'Air Fryer', 'preco': 400.00},
    {'id': 10, 'nome': 'Mouse sem fio Gamer recarregável', 'preco': 120.00},
    {'id': 11, 'nome': 'Caixa de som bluetooth', 'preco': 180.00},
    {'id': 12, 'nome': 'Tablet 10 polegadas', 'preco': 900.00},
    {'id': 13, 'nome': 'Smartwatch básico', 'preco': 350.00},
    {'id': 14, 'nome': 'Teclado sem fio', 'preco': 280.00},
    {'id': 15, 'nome': 'Câmera de segurança IP', 'preco': 480.00},
    {'id': 16, 'nome': 'Carregador portátil (Power Bank)', 'preco': 150.00},
    {'id': 17, 'nome': 'Ventilador de mesa', 'preco': 120.00},
    {'id': 18, 'nome': 'Geladeira pequena (1 porta)', 'preco': 1200.00},
    {'id': 19, 'nome': 'Liquidificador', 'preco': 180.00},
    {'id': 20, 'nome': 'Micro-ondas compacto', 'preco': 650.00}
    ]

    def get_produtos(self):
        return self.PRODUTOS
    


    def add(self, nome, preco):
        n = 1
        for i in self.PRODUTOS:
            n += 1
       
        novo_produto = {'id':n,'nome':nome, 'preco':preco}
        self.PRODUTOS.append(novo_produto)        
        
    
    def deletar(self,id):
        id2 = int(id)
        n = 0
        for i in self.PRODUTOS:
            if i['id'] == id2:
                self.PRODUTOS.pop(n)
                break
            n += 1


