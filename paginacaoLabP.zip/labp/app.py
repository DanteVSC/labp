from flask import Flask, render_template, request, abort, jsonify
import math
app = Flask(__name__)

#lista de produtos
PRODUTOS = [
    {'id': 1, 'nome': 'Notebook Gamer', 'preco': 5200.00},
    {'id': 2, 'nome': 'Mouse sem fio', 'preco': 150.00},
    {'id': 3, 'nome': 'Teclado Mecanico RGB', 'preco': 350.00},
    {'id': 4, 'nome': 'Smartphone intermediário', 'preco': 1800.00},
    {'id': 5, 'nome': 'Smart TV 50 polegadas', 'preco': 3200.00},
    {'id': 6, 'nome': 'Fone de ouvido Bluetooth', 'preco': 250.00},
    {'id': 7, 'nome': 'Ventilador de coluna', 'preco': 260.00},
    {'id': 8, 'nome': 'Aspirador de pó e água', 'preco': 290.00},
    {'id': 9, 'nome': 'Air Fryer', 'preco': 400.00},
    {'id': 10, 'nome': 'Mouse sem fio Gamer recarregável', 'preco': 120.00},
    {'id': 11, 'nome': 'Caixa de som bluetooth', 'preco': 180.00},
    {'id': 12, 'nome': 'Tablet 10 polegadas', 'preco': 900.00},
    {'id': 13, 'nome': 'Smartwatch básico', 'preco': 350.00},
    {'id': 14, 'nome': 'Teclado sem fio', 'preco': 280.00},
    {'id': 15, 'nome': 'Câmera de segurança IP', 'preco': 480.00},
    {'id': 16, 'nome': 'Carregador portátil (Power Bank)', 'preco': 150.00},
    {'id': 17, 'nome': 'Ventilador de mesa', 'preco': 120.00},
    {'id': 18, 'nome': 'Geladeira pequena (1 porta)', 'preco': 1200.00},
    {'id': 19, 'nome': 'Liquidificador', 'preco': 180.00},
    {'id': 20, 'nome': 'Micro-ondas compacto', 'preco': 650.00}
]


@app.route('/produtos')
def listar_produtos():
    return render_template('produtos.html', produtos=PRODUTOS)

@app.route('/produtos-paginados')
def listar_produtos_paginados():
    page = request.arg.get('page', 1, type=int)
    per_page = 5

    #logica da paginacao    
    start = (page-1)*per_page
    end = start + per_page
    total_pages = math.ceil(len(PRODUTOS)/per_page)

    #pega itens apenas da pagina atual
    produtos_da_pagina = PRODUTOS[start:end]

    return render_template('produtos_paginados.html', produtos=produtos_da_pagina, page=page,total_pages=total_pages)

@app.route('/produto/<int:produto_id>')
def detalhe_produto(produto_id):
    produto_encontrado = None

    for produto in PRODUTOS:
        if produto["id"] == produto_id:
             produto_encontrado = produto
             break
    if produto_encontrado is None:
        abort(404) 
    return render_template('detalhe_produto.html',produto=produto_encontrado)

@app.route('/api/buscar-produto',methods=['POST'])
def buscar_produto():
    dados = request.get_json()
    nome_produto = dados.get('nome').lower()

    resultado = [p for p in PRODUTOS if nome_produto in p['nome'].lower()]

    return jsonify({'produtos_encontrados':resultado})

if __name__ == '__main__':
        app.run(debug=True)